# Lotto 645 prediction test


Summary
----------
>



Environment
----------
```sh
Python: v3.7.4
sklearn, micromlgen
```



Installation and Run
----------
```sh
$ pip3 install numpy
$ pip3 install pandas
$ pip3 install sklearn

$ pip install micromlgen
or
$ pip install https://github.com/eloquentarduino/micromlgen.git



$ python3 test_lotto645.py
```
